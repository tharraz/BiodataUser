package com.example.biodatauserapp.ui.main;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.biodatauserapp.databinding.ActivityMainBinding;
import com.example.biodatauserapp.models.UsersResponse;
import com.example.biodatauserapp.models.UsersResponseItem;
import com.example.biodatauserapp.ui.adapter.UserAdapter;
import com.example.biodatauserapp.ui.detail.DetailActivity;

import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;

    private UserAdapter userAdapter = new UserAdapter();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setRecyclerView();
        setContents();
    }

    private void setRecyclerView() {
        userAdapter.setOnEventClickListener(event -> {
            Intent iDetail = new Intent(this, DetailActivity.class);
            iDetail.putExtra(DetailActivity.USER_EXTRA, event);
            startActivity(iDetail);
        });

        binding.rvUser.setAdapter(userAdapter);
        binding.rvUser.setLayoutManager(new LinearLayoutManager(this));
    }

    private void setContents() {
        showLoading(true);
        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);

        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(loggingInterceptor)
                .build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://jsonplaceholder.typicode.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        retrofit.create(APIService.class).getUsers().enqueue(new Callback<List<UsersResponseItem>>() {
            @Override
            public void onResponse(@NonNull Call<List<UsersResponseItem>> call, @NonNull Response<List<UsersResponseItem>> response) {
                showLoading(false);
                List<UsersResponseItem> usersResponseItemList = response.body();
                userAdapter.submitData(usersResponseItemList);

                Log.e("FTEST", "onResponse: " + usersResponseItemList.size());
            }

            @Override
            public void onFailure(@NonNull Call<List<UsersResponseItem>> call, @NonNull Throwable throwable) {
                showLoading(false);
                Log.e("FTEST", "error: " + throwable.getLocalizedMessage());

                Toast.makeText(MainActivity.this, "Error : " + throwable.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showLoading(Boolean isLoading) {
        if (isLoading) {
            binding.progressbar.setVisibility(View.VISIBLE);
            binding.progressbar.setIndeterminate(true);
        } else {
            binding.progressbar.setVisibility(View.GONE);
            binding.progressbar.setIndeterminate(false);
        }
    }

    public interface APIService {
        @GET("users")
        Call<List<UsersResponseItem>> getUsers();
    }
}
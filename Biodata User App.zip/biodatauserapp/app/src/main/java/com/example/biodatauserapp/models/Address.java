package com.example.biodatauserapp.models;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

public class Address implements Parcelable {

    @SerializedName("zipcode")
    private String zipcode;

    @SerializedName("suite")
    private String suite;

    @SerializedName("city")
    private String city;

    @SerializedName("street")
    private String street;

    public String getZipcode() {
        return zipcode;
    }

    public String getSuite() {
        return suite;
    }

    public String getCity() {
        return city;
    }

    public String getStreet() {
        return street;
    }

    protected Address(Parcel in) {
        zipcode = in.readString();
        suite = in.readString();
        city = in.readString();
        street = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(zipcode);
        dest.writeString(suite);
        dest.writeString(city);
        dest.writeString(street);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Address> CREATOR = new Creator<Address>() {
        @Override
        public Address createFromParcel(Parcel in) {
            return new Address(in);
        }

        @Override
        public Address[] newArray(int size) {
            return new Address[size];
        }
    };
}
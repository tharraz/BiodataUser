package com.example.biodatauserapp.models;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

import java.util.Objects;

public class UsersResponseItem implements Parcelable {

    @SerializedName("website")
    private String website;

    @SerializedName("address")
    private Address address;

    @SerializedName("phone")
    private String phone;

    @SerializedName("name")
    private String name;

    @SerializedName("id")
    private int id;

    @SerializedName("email")
    private String email;

    @SerializedName("username")
    private String username;

    public String getWebsite() {
        return website;
    }

    public Address getAddress() {
        return address;
    }

    public String getPhone() {
        return phone;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    public String getUsername() {
        return username;
    }

    protected UsersResponseItem(Parcel in) {
        website = in.readString();
        address = in.readParcelable(Address.class.getClassLoader());
        phone = in.readString();
        name = in.readString();
        id = in.readInt();
        email = in.readString();
        username = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(website);
        dest.writeParcelable(address, flags);
        dest.writeString(phone);
        dest.writeString(name);
        dest.writeInt(id);
        dest.writeString(email);
        dest.writeString(username);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UsersResponseItem that = (UsersResponseItem) o;
        return id == that.id &&
                Objects.equals(website, that.website) &&
                Objects.equals(address, that.address) &&
                Objects.equals(phone, that.phone) &&
                Objects.equals(name, that.name) &&
                Objects.equals(email, that.email) &&
                Objects.equals(username, that.username);
    }

    public static final Creator<UsersResponseItem> CREATOR = new Creator<UsersResponseItem>() {
        @Override
        public UsersResponseItem createFromParcel(Parcel in) {
            return new UsersResponseItem(in);
        }

        @Override
        public UsersResponseItem[] newArray(int size) {
            return new UsersResponseItem[size];
        }
    };
}
package com.example.biodatauserapp.ui.detail;

import android.os.Build;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.biodatauserapp.R;
import com.example.biodatauserapp.databinding.ActivityDetailBinding;
import com.example.biodatauserapp.models.UsersResponseItem;

public class DetailActivity extends AppCompatActivity {
    private ActivityDetailBinding binding;

    public static String USER_EXTRA = "user_extra";
    private UsersResponseItem userDetail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            userDetail = getIntent().getParcelableExtra(USER_EXTRA, UsersResponseItem.class);
        } else {
            userDetail = getIntent().getParcelableExtra(USER_EXTRA);
        }

        setContents();
    }

    private void setContents() {
        String fullAddress = userDetail.getAddress().getSuite() + ", " + userDetail.getAddress().getStreet() + ", " + userDetail.getAddress().getCity() + ".";

        binding.tvName.setText(userDetail.getName());
        binding.tvUsername.setText(userDetail.getUsername());
        binding.tvAddress.setText(fullAddress);
        binding.tvPhone.setText(userDetail.getPhone());
        binding.tvEmail.setText(userDetail.getEmail());
    }
}
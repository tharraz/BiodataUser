package com.example.biodatauserapp.models;

import java.util.List;
import com.google.gson.annotations.SerializedName;

public class UsersResponse{

	@SerializedName("UsersResponse")
	private List<UsersResponseItem> usersResponse;

	public List<UsersResponseItem> getUsersResponse(){
		return usersResponse;
	}
}
package com.example.biodatauserapp.ui.adapter;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.AsyncListDiffer;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.example.biodatauserapp.databinding.ItemUserRowBinding;
import com.example.biodatauserapp.models.UsersResponseItem;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.EventViewHolder> {

    private final AsyncListDiffer<UsersResponseItem> differ = new AsyncListDiffer<>(this, new EventDiffCallback());
    private OnEventClickListener onEventClick;

    public void submitData(List<UsersResponseItem> events) {
        differ.submitList(events);
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemUserRowBinding binding = ItemUserRowBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false
        );
        return new EventViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        holder.bind(differ.getCurrentList().get(position), onEventClick);
    }

    @Override
    public int getItemCount() {
        return differ.getCurrentList().size();
    }

    public void setOnEventClickListener(OnEventClickListener listener) {
        this.onEventClick = listener;
    }

    public static class EventViewHolder extends RecyclerView.ViewHolder {

        private final ItemUserRowBinding binding;

        public EventViewHolder(@NonNull ItemUserRowBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(UsersResponseItem event, OnEventClickListener onItemClick) {

            binding.tvName.setText(event.getName());
            binding.tvUsername.setText(event.getUsername());
            binding.tvEmail.setText(event.getEmail());

            binding.cardItem.setOnClickListener(v -> {
                if (onItemClick != null) {
                    onItemClick.onEventClick(event);
                }
            });
        }
    }

    public static class EventDiffCallback extends DiffUtil.ItemCallback<UsersResponseItem> {
        @Override
        public boolean areItemsTheSame(@NonNull UsersResponseItem oldItem, @NonNull UsersResponseItem newItem) {
            return oldItem.getId() == newItem.getId();
        }

        @Override
        public boolean areContentsTheSame(@NonNull UsersResponseItem oldItem, @NonNull UsersResponseItem newItem) {
            return oldItem.equals(newItem);
        }
    }

    public interface OnEventClickListener {
        void onEventClick(UsersResponseItem event);
    }
}